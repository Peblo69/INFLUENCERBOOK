import { ChunkEditor } from "@/sections/MainContent/components/ChunkEditor";

export const PromptRenderer = () => {
  return (
    <div className="box-border caret-transparent">
      <ChunkEditor />
    </div>
  );
};
