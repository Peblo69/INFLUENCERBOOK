export const Logo = () => {
  return (
    <div type="lockup" className="box-border caret-transparent">
      <img
        src="https://c.animaapp.com/mi25bw52nYdnr2/assets/icon-1.svg"
        alt="Icon"
        className="box-border caret-transparent w-full"
      />
    </div>
  );
};
